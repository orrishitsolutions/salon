<div class="main">
<header class="header headersot active">
   <div class="container-fluid">
      <nav class="navbar navbar-expand-lg navbar-light">
         <div class="container-fluid">
            <menu class="menusbartoggle">
               <label for="trigger">
                  <div class="drawer-list">
                     <div class="sidebar-menu">
                        <ul class="sectionulines">
                           <li><a href="index.php" class="slideimages"><img
                              src="assets/img/orrish-logo2.png" alt="logo" /></a></li>
                           <li><a class="slideimages"><button class="sing-btn" data-bs-toggle="modal" data-bs-target="#exampleModal">SIGN UP</button></a></li>
                           <li class="menu1">
                              <a class="active3" href="#">
                                 <i class="far fa-address-card"></i>
                                 <p> About <span>Company</span></p>
                                 <i class="fas fa-long-arrow-alt-right float3"></i>
                              </a>
                              <div class="part3slidemenu part3slidemenu11 active">
                                 <ul class="sectionulines2">
                                    <li class="menu2">
                                       <a href="about.php">About Us<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus paramenus11 active">
                                          <p>If you wish to get everything on yourfingertips,
                                             that’s where you have to be!From chatbots to
                                             artificial intelligencedevelopment, every
                                             leading business isadapting to the latest
                                             technologies tosummon up to better credibility
                                             andexperience for the
                                             users.<br></br>OwebestTechnologies Pvt. Ltd.
                                             delivers high-endfascinating IT solutions to
                                             businesses.‘Class’ and ‘Authenticity’ is what
                                             webelieve in, and we work to deliver
                                             nothingless! We work on new ideas and
                                             conceptsthat are approachable for
                                             clients’success. We focus on professional
                                             andagile methodologies to prove worth yourtime
                                             and investment in IT SolutionCompany. Because
                                             maintainingimplementation support with
                                             dedicatedinvolvement is what we commit to
                                             ourclients.
                                          </p>
                                          <a href="about.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="about.php">Our Vission<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our vision is to develop continually andgrow as a
                                             leading IT service provider inthe competitive
                                             global marketplace. Ourapproach to a
                                             professional, flexible andintegrated development
                                             reflects in what wedo. We always work to direct
                                             our customersto success. Our talented team
                                             ofprofessionals, shaped by their years
                                             ofexperience in the corporate world, worksto
                                             fill the gap between the practicalrequirements
                                             or aspects and the digitalworld. With the right
                                             combination ofpassion and skills, our crew
                                             trulyaccelerates the growth of yourorganization.
                                          </p>
                                          <a href="about.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="about.php">Our Mission<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our mission is to grow our customers’businesses
                                             by delivering creative andinnovative solutions
                                             and services thatcreate value and a genuine
                                             competitiveadvantage. We, at Owebest, follow
                                             afive-step plan to our mission of success.
                                          </p>
                                          <a href="about.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="about.php">Our Approach<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our approach to project management issimple. We
                                             aim to clearly identify thevalue and project
                                             objectives of ourclients. Once these are
                                             identified, wework to create value for our
                                             clients bydeveloping and fostering a
                                             collaborativeteam environment that
                                             encouragesinnovative thinking and sharing of
                                             ideasamong all the members of the project
                                             team.Resultantly, our clients come in aposition
                                             to make more informed andeffective decisions
                                             related to theproject.
                                          </p>
                                          <a href="about.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="about.php">Internship<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>To experience the best summer aftergraduation, it
                                             is important to hold on toan internship program
                                             that can help youfeel close to the latest
                                             technologies.Owebest Technologies Pvt. Ltd.
                                             offers aprofessional environment to the interns
                                             tobestow the best of your knowledge
                                             andabilities. We understand how important itis
                                             to learn from the best, especially atthe initial
                                             level of your career. Andthat’s were
                                             knowledgeable engineers lookfor an internship in
                                             IT companies. Weoffer a distinct learning
                                             platform to workclosely with the latest
                                             technologydevelopment.
                                          </p>
                                          <a href="about.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="franchise.php">Franchise Opportunities<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>We offer a wide portfolio of servicesincluding
                                             Website/Web App Design andDevelopment, Mobile
                                             App Development,Internet Marketing services,
                                             Security andVulnerability Testing, Bug Fixing
                                             andMaintenance, and other supportiveservices,
                                             literally enabling you to createa design and
                                             development business withabsolutely no
                                             technology cost.
                                          </p>
                                          <a href="about.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="testimonails.php">Testimonials<i
                                          class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Client Testimonials and Reviews</p>
                                          <a href="testimonails.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="blog.php">Blogs<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Well, we all know that reading helps youdiscover
                                             the latest trends out there! Ourblog section
                                             will help you understand thetechnological
                                             development in the worldclosely. It’s not just
                                             worth a read, butworth a try to discover your
                                             creativethoughts. Reading a blog on
                                             differenttechnologies and strategies of
                                             technicalproduct, it helps the clients
                                             tounderstand and decide what is best suitedfor
                                             their business and values. After all,every
                                             technical product has a story behindand vision
                                             behind it that must beunderstood. So if you feel
                                             confused as ifArtificial Intelligence is the
                                             bestservice or Big data for your company
                                             andservices; you might want to read aboutthem
                                             first. In case you are looking for apanel to
                                             discover different ways tomarketing and
                                             digitalizing your services;our blog section will
                                             help you understandthe panel in the simplest yet
                                             smarter waypossible. And it’s with knowledge
                                             andreading that you will understand
                                             thedifference in each segment of technologyto
                                             help you decide what is best for yourbusiness.
                                             So sale out your schedule toread different eras
                                             of technologies on ourblog segment; because you
                                             might justdiscover the next best thing for
                                             yourbusiness!
                                          </p>
                                          <a href="blog.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="carrer.php">Carrer<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Owebest is the one-stop solution for IT.It is one
                                             of the leading IT companies inJaipur, Rajasthan.
                                             To get aligned rightthe method of the Owebest is
                                             pretty simple& certainly worth. We find out
                                             thematters, draw outlines, reshape it,broaden,
                                             take a look at and supply. Thegrade by grade
                                             technique is the mosteffective key to make the
                                             presentationattractive and fantastic. Take a
                                             step andget in touch with us. You may also
                                             visitthe stuff we have executed for
                                             ourcustomers, it'll clear you all of yourdoubts
                                             & queries about being the best.
                                          </p>
                                          <a href="carrer.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                 </ul>
                                 <div class="logoicon"><img src="assets/img/icon1.png"
                                    alt=""><img src="assets/img/icon2.png" alt=""><img
                                    src="assets/img/icon3.png" alt=""><img
                                    src="assets/img/icon4.png" alt=""><img
                                    src="assets/img/icon5.png" alt=""></div>
                              </div>
                           </li>
                           <li class="menu1">
                              <a href="work.php">
                                 <i class="fas fa-cut"></i> 
                                 <p>Explore <span> Our Work</span></p>
                                 <i class="fas fa-long-arrow-alt-right float3"></i>
                              </a>
                              <div class="part3slidemenu">
                                 <ul class="sectionulines2">
                                    <li class="menu2">
                                       <a href="essantial-salon-spa.php">essantial salon & spa <i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus paramenus11 active">
                                          <p>If you wish to get everything on yourfingertips,
                                             that’s where you have to be!From chatbots to
                                             artificial intelligencedevelopment, every
                                             leading business isadapting to the latest
                                             technologies tosummon up to better credibility
                                             andexperience for the
                                             users.<br></br>OwebestTechnologies Pvt. Ltd.
                                             delivers high-endfascinating IT solutions to
                                             businesses.‘Class’ and ‘Authenticity’ is what
                                             webelieve in, and we work to deliver
                                             nothingless! We work on new ideas and
                                             conceptsthat are approachable for
                                             clients’success. We focus on professional
                                             andagile methodologies to prove worth yourtime
                                             and investment in IT SolutionCompany. Because
                                             maintainingimplementation support with
                                             dedicatedinvolvement is what we commit to
                                             ourclients.
                                          </p>
                                          <a href="essantial-salon-spa.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">salon at home<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our vision is to develop continually andgrow as a
                                             leading IT service provider inthe competitive
                                             global marketplace. Ourapproach to a
                                             professional, flexible andintegrated development
                                             reflects in what wedo. We always work to direct
                                             our customersto success. Our talented team
                                             ofprofessionals, shaped by their years
                                             ofexperience in the corporate world, worksto
                                             fill the gap between the practicalrequirements
                                             or aspects and the digitalworld. With the right
                                             combination ofpassion and skills, our crew
                                             trulyaccelerates the growth of yourorganization.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">skin problems face treatment<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our mission is to grow our customers’businesses
                                             by delivering creative andinnovative solutions
                                             and services thatcreate value and a genuine
                                             competitiveadvantage. We, at Owebest, follow
                                             afive-step plan to our mission of success.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">body cappuccino & polishing<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our approach to project management issimple. We
                                             aim to clearly identify thevalue and project
                                             objectives of ourclients. Once these are
                                             identified, wework to create value for our
                                             clients bydeveloping and fostering a
                                             collaborativeteam environment that
                                             encouragesinnovative thinking and sharing of
                                             ideasamong all the members of the project
                                             team.Resultantly, our clients come in aposition
                                             to make more informed andeffective decisions
                                             related to theproject.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">dark bikini & underarms<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>To experience the best summer aftergraduation, it
                                             is important to hold on toan internship program
                                             that can help youfeel close to the latest
                                             technologies.Owebest Technologies Pvt. Ltd.
                                             offers aprofessional environment to the interns
                                             tobestow the best of your knowledge
                                             andabilities. We understand how important itis
                                             to learn from the best, especially atthe initial
                                             level of your career. Andthat’s were
                                             knowledgeable engineers lookfor an internship in
                                             IT companies. Weoffer a distinct learning
                                             platform to workclosely with the latest
                                             technologydevelopment.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">body brightener<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>We offer a wide portfolio of servicesincluding
                                             Website/Web App Design andDevelopment, Mobile
                                             App Development,Internet Marketing services,
                                             Security andVulnerability Testing, Bug Fixing
                                             andMaintenance, and other supportiveservices,
                                             literally enabling you to createa design and
                                             development business withabsolutely no
                                             technology cost.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">wellness work<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Client Testimonials and Reviews</p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">fashion work<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Well, we all know that reading helps youdiscover
                                             the latest trends out there! Ourblog section
                                             will help you understand thetechnological
                                             development in the worldclosely. It’s not just
                                             worth a read, butworth a try to discover your
                                             creativethoughts. Reading a blog on
                                             differenttechnologies and strategies of
                                             technicalproduct, it helps the clients
                                             tounderstand and decide what is best suitedfor
                                             their business and values. After all,every
                                             technical product has a story behindand vision
                                             behind it that must beunderstood. So if you feel
                                             confused as ifArtificial Intelligence is the
                                             bestservice or Big data for your company
                                             andservices; you might want to read aboutthem
                                             first. In case you are looking for apanel to
                                             discover different ways tomarketing and
                                             digitalizing your services;our blog section will
                                             help you understandthe panel in the simplest yet
                                             smarter waypossible. And it’s with knowledge
                                             andreading that you will understand
                                             thedifference in each segment of technologyto
                                             help you decide what is best for yourbusiness.
                                             So sale out your schedule toread different eras
                                             of technologies on ourblog segment; because you
                                             might justdiscover the next best thing for
                                             yourbusiness!
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">beauty work<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Owebest is the one-stop solution for IT.It is one
                                             of the leading IT companies inJaipur, Rajasthan.
                                             To get aligned rightthe method of the Owebest is
                                             pretty simple& certainly worth. We find out
                                             thematters, draw outlines, reshape it,broaden,
                                             take a look at and supply. Thegrade by grade
                                             technique is the mosteffective key to make the
                                             presentationattractive and fantastic. Take a
                                             step andget in touch with us. You may also
                                             visitthe stuff we have executed for
                                             ourcustomers, it'll clear you all of yourdoubts
                                             & queries about being the best.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">academy program<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Owebest is the one-stop solution for IT.It is one
                                             of the leading IT companies inJaipur, Rajasthan.
                                             To get aligned rightthe method of the Owebest is
                                             pretty simple& certainly worth. We find out
                                             thematters, draw outlines, reshape it,broaden,
                                             take a look at and supply. Thegrade by grade
                                             technique is the mosteffective key to make the
                                             presentationattractive and fantastic. Take a
                                             step andget in touch with us. You may also
                                             visitthe stuff we have executed for
                                             ourcustomers, it'll clear you all of yourdoubts
                                             & queries about being the best.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                 </ul>
                                 <div class="logoicon">
                                    <img src="assets/img/icon1.png" alt="">
                                    <img src="assets/img/icon2.png" alt="">
                                    <img src="assets/img/icon3.png" alt="">
                                    <img src="assets/img/icon4.png" alt="">
                                    <img src="assets/img/icon5.png" alt="">
                                 </div>
                              </div>
                           </li>
                           <li class="menu1">
                              <a href="services.php">
                                 <i class="fas fa-air-freshener"></i>
                                 <p>Our <span>Services</span></p>
                                 <i class="fas fa-long-arrow-alt-right float3"></i>
                              </a>
                              <div class="part3slidemenu">
                                 <ul class="sectionulines2">
                                    <li class="menu2">
                                       <a href="men-services.php">Our Services - Men<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus paramenus11 active">
                                          <div class="row">
                                             <div class="col-md-12">
                                                <h5>For Men</h5>
                                                <p> We just don’t talk; we deliver! And our
                                                   work portfolio will help learn about
                                                   ourwork and creative delivery is done so
                                                   far. Serving the best technical
                                                   solutions andholding on to the committed
                                                   quality can be seen in your portfolio.
                                                </p>
                                             </div>
                                          </div>
                                          <ul class="submenus-dp">
                                             <li><a href="men-services.php"><img src="assets/img/wax.png">
                                                <span> Bleach</span></a>
                                             </li>
                                             <li><a href="services.php"><img src="assets/img/body.png">
                                                <span> Body Care</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/waximg.png"> <span>
                                                De-Tan Pack</span></a>
                                             </li>
                                             <li><a href="#1"><img src="assets/img/make.png">
                                                <span> Deal of The Day</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/face.png"><span>
                                                Face Care</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/hair.png"><span>
                                                Hair Care</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/bodys.png"> <span>
                                                Manicure & Pedicure</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/makeup.png"> <span>
                                                Party Makeup</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/custom.png"> <span>
                                                Threading</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/wax.png"><span>
                                                Waxing</span></a>
                                             </li>
                                             <li><a href="#1"><img
                                                src="assets/img/prebody.png"> <span>
                                                Pre Bridal</span> </a>
                                             </li>
                                          </ul>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="women-services.php">Our Services - Women <i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <div class="row">
                                             <div class="col-md-12">
                                                <h5>For Women</h5>
                                                <p> We just don’t talk; we deliver! And our
                                                   work portfolio will help learn about
                                                   ourwork and creative delivery is done so
                                                   far. Serving the best technical
                                                   solutions andholding on to the committed
                                                   quality can be seen in your portfolio.
                                                </p>
                                             </div>
                                          </div>
                                          <ul class="submenus-dp">
                                             <li><a href="women-services.php"><img src="assets/img/wax.png">
                                                <span> Bleach</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img src="assets/img/body.png">
                                                <span> Body Care</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/waximg.png"> <span>
                                                De-Tan Pack</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img src="assets/img/make.png">
                                                <span> Deal of The Day</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/face.png"><span>
                                                Face Care</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/hair.png"><span>
                                                Hair Care</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/bodys.png"> <span>
                                                Manicure & Pedicure</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/makeup.png"> <span>
                                                Party Makeup</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/custom.png"> <span>
                                                Threading</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/wax.png"><span>
                                                Waxing</span></a>
                                             </li>
                                             <li><a href="women-services.php"><img
                                                src="assets/img/prebody.png"> <span>
                                                Pre Bridal</span> </a>
                                             </li>
                                          </ul>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="services.php">Our in – Trend Makeovers<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <h5>Our in – Trend Makeovers</h5>
                                          <p>Our mission is to grow our customers’businesses
                                             by delivering creative andinnovative solutions
                                             and services thatcreate value and a genuine
                                             competitiveadvantage. We, at Owebest, follow
                                             afive-step plan to our mission of success.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="services.php">Our cause – Shair<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <h5>Impact of our Initiative</h5>
                                          <p>
                                             Launched on World Cancer Day, February 4, 2015,
                                             Salon has run its hair donation program for 5
                                             successful years of hair donation and spreading
                                             awareness across the country across all its 375+
                                             salons across India and across standalone hair
                                             donation camps conducted in colleges, schools
                                             and corporate. With an aim to encourage
                                             Corporate Firms, Educational Institutes and
                                             Social Organisation, the brand has also launched
                                             ‘ShairAnywhere’ program in which a specially
                                             trained team of stylists will visit the
                                             participating organisation and conduct free hair
                                             donation camps within the respective premises. A
                                             pink hair extension that represents the symbol
                                             of hair donation will be given to every donor to
                                             help spread awareness to the cause. Every donor
                                             will also be presented with a certificate of
                                             appreciation to recognize their contribution.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                 </ul>
                                 <div class="logoicon"><img src="assets/img/icon1.png"
                                    alt=""><img src="assets/img/icon2.png" alt=""><img
                                    src="assets/img/icon3.png" alt=""><img
                                    src="assets/img/icon4.png" alt=""><img
                                    src="assets/img/icon5.png" alt=""></div>
                              </div>
                           </li>
                           <li class="menu1">
                              <a href="package.php">
                                 <i class="fas fa-cubes"></i> All 
                                 <p><span>Packages</span></p>
                                 <i class="fas fa-long-arrow-alt-right float3"></i>
                              </a>
                              <div class="part3slidemenu">
                                 <ul class="sectionulines2">
                                    <li class="menu2">
                                       <a href="package.php">Festive Packages<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus paramenus11 active">
                                          <p>If you wish to get everything on yourfingertips,
                                             that’s where you have to be!From chatbots to
                                             artificial intelligencedevelopment, every
                                             leading business isadapting to the latest
                                             technologies tosummon up to better credibility
                                             andexperience for the
                                             users.<br></br>OwebestTechnologies Pvt. Ltd.
                                             delivers high-endfascinating IT solutions to
                                             businesses.‘Class’ and ‘Authenticity’ is what
                                             webelieve in, and we work to deliver
                                             nothingless! We work on new ideas and
                                             conceptsthat are approachable for
                                             clients’success. We focus on professional
                                             andagile methodologies to prove worth yourtime
                                             and investment in IT SolutionCompany. Because
                                             maintainingimplementation support with
                                             dedicatedinvolvement is what we commit to
                                             ourclients.
                                          </p>
                                          <a href="package.php" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">Silver Package<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our vision is to develop continually andgrow as a
                                             leading IT service provider inthe competitive
                                             global marketplace. Ourapproach to a
                                             professional, flexible andintegrated development
                                             reflects in what wedo. We always work to direct
                                             our customersto success. Our talented team
                                             ofprofessionals, shaped by their years
                                             ofexperience in the corporate world, worksto
                                             fill the gap between the practicalrequirements
                                             or aspects and the digitalworld. With the right
                                             combination ofpassion and skills, our crew
                                             trulyaccelerates the growth of yourorganization.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">Gold Package<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our mission is to grow our customers’businesses
                                             by delivering creative andinnovative solutions
                                             and services thatcreate value and a genuine
                                             competitiveadvantage. We, at Owebest, follow
                                             afive-step plan to our mission of success.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">Platinum Package<i  class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Our approach to project management issimple. We
                                             aim to clearly identify thevalue and project
                                             objectives of ourclients. Once these are
                                             identified, wework to create value for our
                                             clients bydeveloping and fostering a
                                             collaborativeteam environment that
                                             encouragesinnovative thinking and sharing of
                                             ideasamong all the members of the project
                                             team.Resultantly, our clients come in aposition
                                             to make more informed andeffective decisions
                                             related to theproject.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">BeautyGlad Packages<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>To experience the best summer aftergraduation, it
                                             is important to hold on toan internship program
                                             that can help youfeel close to the latest
                                             technologies.Owebest Technologies Pvt. Ltd.
                                             offers aprofessional environment to the interns
                                             tobestow the best of your knowledge
                                             andabilities. We understand how important itis
                                             to learn from the best, especially atthe initial
                                             level of your career. Andthat’s were
                                             knowledgeable engineers lookfor an internship in
                                             IT companies. Weoffer a distinct learning
                                             platform to workclosely with the latest
                                             technologydevelopment.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">Rica Special Package<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>We offer a wide portfolio of servicesincluding
                                             Website/Web App Design andDevelopment, Mobile
                                             App Development,Internet Marketing services,
                                             Security andVulnerability Testing, Bug Fixing
                                             andMaintenance, and other supportiveservices,
                                             literally enabling you to createa design and
                                             development business withabsolutely no
                                             technology cost.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">Rica Wax & De-Tan<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Client Testimonials and Reviews</p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">Classic Package<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Well, we all know that reading helps youdiscover
                                             the latest trends out there! Ourblog section
                                             will help you understand thetechnological
                                             development in the worldclosely. It’s not just
                                             worth a read, butworth a try to discover your
                                             creativethoughts. Reading a blog on
                                             differenttechnologies and strategies of
                                             technicalproduct, it helps the clients
                                             tounderstand and decide what is best suitedfor
                                             their business and values. After all,every
                                             technical product has a story behindand vision
                                             behind it that must beunderstood. So if you feel
                                             confused as ifArtificial Intelligence is the
                                             bestservice or Big data for your company
                                             andservices; you might want to read aboutthem
                                             first. In case you are looking for apanel to
                                             discover different ways tomarketing and
                                             digitalizing your services;our blog section will
                                             help you understandthe panel in the simplest yet
                                             smarter waypossible. And it’s with knowledge
                                             andreading that you will understand
                                             thedifference in each segment of technologyto
                                             help you decide what is best for yourbusiness.
                                             So sale out your schedule toread different eras
                                             of technologies on ourblog segment; because you
                                             might justdiscover the next best thing for
                                             yourbusiness!
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                    <li class="menu2">
                                       <a href="#">Smooth Skin<i class="fas fa-long-arrow-alt-right"></i></a>
                                       <div class="paramenus">
                                          <p>Owebest is the one-stop solution for IT.It is one
                                             of the leading IT companies inJaipur, Rajasthan.
                                             To get aligned rightthe method of the Owebest is
                                             pretty simple& certainly worth. We find out
                                             thematters, draw outlines, reshape it,broaden,
                                             take a look at and supply. Thegrade by grade
                                             technique is the mosteffective key to make the
                                             presentationattractive and fantastic. Take a
                                             step andget in touch with us. You may also
                                             visitthe stuff we have executed for
                                             ourcustomers, it'll clear you all of yourdoubts
                                             & queries about being the best.
                                          </p>
                                          <a href="#1" class="sing-btn">  View More </a>
                                       </div>
                                    </li>
                                 </ul>
                                 <div class="logoicon"><img src="assets/img/icon1.png"
                                    alt=""><img src="assets/img/icon2.png" alt=""><img
                                    src="assets/img/icon3.png" alt=""><img
                                    src="assets/img/icon4.png" alt=""><img
                                    src="assets/img/icon5.png" alt=""></div>
                              </div>
                           </li>
                           <li class="menu1">
                              <a href="portfolio.php">
                                 <i class="fab fa-accusoft"></i> Work 
                                 <p><span>portfolio</span></p>
                                 <i class="fas fa-long-arrow-alt-right float3"></i>
                              </a>
                              <div class="part3slidemenu">
                                 <div class="row portfolios_dp">
                                    <div class="col-md-3"><img
                                       src="assets/img/wecast-cover-small.png" alt="">
                                    </div>
                                    <div class="col-md-3"><img
                                       src="assets/img/vebo-cover-small.png" alt=""></div>
                                    <div class="col-md-3"><img
                                       src="assets/img/apjpro-cover-small.png" alt="">
                                    </div>
                                    <div class="col-md-3"><img
                                       src="assets/img/foodhub-cover.png" alt=""></div>
                                    <div class="col-md-12">
                                       <p class=" pt0-20"> We just don’t talk; we deliver! And
                                          our work portfolio will help learn about ourwork and
                                          creative delivery is done so far. Serving the best
                                          technical solutions andholding on to the committed
                                          quality can be seen in your portfolio. Our happy
                                          clientshave been holding on to our services because
                                          they were delivered the best of thecreative idea we
                                          thought of initially!<br></br>So if you have an
                                          initial creative thought and wish to transform it
                                          into a technicalreality, Owebest Technologies Pvt.
                                          Ltd. will serve you on the right path to
                                          success.Check out our latest products and creative
                                          inventions delivered to our clients.
                                       </p>
                                    </div>
                                 </div>
                                 <div class="logoicon"><img src="assets/img/icon1.png"
                                    alt=""><img src="assets/img/icon2.png" alt=""><img
                                    src="assets/img/icon3.png" alt=""><img
                                    src="assets/img/icon4.png" alt=""><img
                                    src="assets/img/icon5.png" alt=""></div>
                              </div>
                           </li>
                           <li class="menu1">
                              <a href="contact-us.php">
                                 <span>
                                    <i class="far fa-address-card"></i>
                                    <p style="    text-transform: capitalize;
                                       line-height: 35px;
                                       font-size: 20px; ">Contact Us</p>
                                 </span>
                                 <i class="fas fa-long-arrow-alt-right float3"></i>
                              </a>
                              <div class="part3slidemenu">
                                 <div class="row portfolios_dp">
                                    <div class="col-md-12">
                                       <p> We just don’t talk; we deliver! And our work
                                          portfolio will help learn about ourwork and creative
                                          delivery is done so far. Serving the best technical
                                          solutions andholding on to the committed quality can
                                          be seen in your portfolio. Our happy clientshave
                                          been holding on to our services because they were
                                          delivered the best of thecreative idea we thought of
                                          initially!<br></br>So if you have an initial
                                          creative thought and wish to transform it into a
                                          technicalreality, Owebest Technologies Pvt. Ltd.
                                          will serve you on the right path to success.Check
                                          out our latest products and creative inventions
                                          delivered to our clients.
                                       </p>
                                       <a href="contact-us.php" class="sing-btn">  View More </a>
                                    </div>
                                 </div>
                                 <div class="logoicon"><img src="assets/img/icon1.png" alt=""><img src="assets/img/icon2.png" alt="">
                                    <img src="assets/img/icon3.png" alt="">
                                    <img src="assets/img/icon4.png" alt="">
                                    <img src="assets/img/icon5.png" alt="">
                                 </div>
                              </div>
                           </li>
                           <li>
                              <div class="bakgroundmenus">
                                 <div class="flex-row">
                                    <div class="flex-col">
                                       <div class="flex-col-inner">
                                          <h5>Enquire Us</h5>
                                          <div class="flex-data">
                                             <p><i class="fa fa-envelope"></i> info@salon.com
                                             </p>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="flex-col">
                                       <div class="flex-col-inner">
                                          <h5>Get in Touch</h5>
                                          <div class="flex-data"><span
                                             class="phone-text mr-1"><i
                                             class="fa fa-phone"></i>
                                             9999999999,</span><span
                                                class="phone-text"><span
                                                class="flagIcon flagIcon-india"></span>+91
                                             9999999999</span>
                                          </div>
                                       </div>
                                    </div>
                                    <div class="flex-col">
                                       <div class="flex-col-inner">
                                          <h5>Follow Us</h5>
                                          <div class="flex-data">
                                             <ul class="social_link_ul list-unstyled mb-0">
                                                <li><a target="_blank" rel="noreferrer"
                                                   href="#1"
                                                   aria-label="Facebook Link"><i
                                                   class="fab fa-facebook-f"></i></a>
                                                </li>
                                                <li><a target="_blank" rel="noreferrer"
                                                   href="#1"
                                                   aria-label="Linkedin Link"><i
                                                   class="fab fa-twitter"></i></a>
                                                </li>
                                                <li><a target="_blank" rel="noreferrer"
                                                   href="#1"
                                                   aria-label="Youtube Link"><i
                                                   class="fab fa-linkedin-in"></i></a>
                                                </li>
                                             </ul>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <hamburger> <i></i> </hamburger>
               </label>
            </menu>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
               <ul class="navbar-nav gamesbuttons">
                  <li class="nav-item dropdown">
                     <a class="nav-link" id="navbarDropdown">All Department<img
                        src="assets/img/services.png" alt=""
                        style="margin-top: -6px;width: 30px;float: right;margin-left: 12px;" /></a>
                     <div class="dropdown-menu">
                        <div class="colammenus">
                           <span class="tab-divider">
                              <ul class="nav nav-pills my-content1">
                                 <li class="active" id="tabone" href="#1a" data-toggle="tab">For
                                    Mens 
                                 </li>
                                 <li id="tabtwo" href="#2a" data-toggle="tab"> For Womens </li>
                              </ul>
                              <div class="tab-content">
                                 <div class="tab-pane" id="1a">
                                    <div class="menli ">
                                       <ul class="menuline my-content2">
                                          <li><a class="dropdown-item" href="services.php"><img
                                             src="assets/img/wax.png"> <span>
                                             Bleach</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/body.png"> <span> Body
                                             Care</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/waximg.png"> <span>
                                             De-Tan Pack</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/make.png"> <span> Deal of The Day</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/face.png"><span> Face Care</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/hair.png"><span> Hair Care</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/bodys.png"> <span>
                                             Manicure & Pedicure</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/makeup.png"> <span>
                                             Party Makeup</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/custom.png"> <span>
                                             Threading</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/wax.png"><span>
                                             Waxing</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/prebody.png"> <span> Pre Bridal</span> </a>
                                          </li>
                                          <!-- <li><a class="dropdown-item" href="#"><img src="assets/img/body.png"> BodyCare</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>Bleach</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>De-Tan Pack</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>Dealof The Day</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>FaceCare</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>HairCare</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>Manicure & Pedicure</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>PartyMakeup</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>Threading</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>Waxing</a></li>
                                             <li><a class="dropdown-item" href="#"><i class="fas fa-cut" aria-hidden="true"></i>PreBridal</a></li> -->
                                       </ul>
                                    </div>
                                 </div>
                                 <div class="tab-pane" id="2a">
                                    <div class="womenli ">
                                       <ul class="womenmenuline my-content2">
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/wax.png"> <span>
                                             Bleach</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img src="assets/img/body.png"> <span> Body Care</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img src="assets/img/waximg.png"> <span>
                                             De-Tan Pack</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/make.png"> <span> Deal of The Day</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/face.png"><span> Face Care</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/hair.png"><span> Hair Care</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/bodys.png"> <span> Manicure & Pedicure</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/makeup.png"> <span> Party Makeup</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/custom.png"> <span> Threading</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/wax.png"><span> Waxing</span></a>
                                          </li>
                                          <li>
                                             <a class="dropdown-item" href="#1"><img
                                                src="assets/img/prebody.png"> <span> Pre Bridal</span> </a>
                                          </li>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </span>
                        </div>
                     </div>
                  </li>
               </ul>
               <a class="navbar-brand mx-auto" href="index.php"><img src="assets/img/orrish-logo.png"
                  alt="logo" style="margin-left: 200px" /></a>
               <ul class="d-flex right-menu m-0">
                  <li class="nav-item sign d-none d-lg-block d-sm-block"><a class="nav-link"
                     href="make-appointment.php">Make An Appointment</a></li>
                  <li class="nav-item sign d-none d-lg-block d-sm-block"><a href="package.php"
                     class="nav-link">All Packages</a></li>
                  <li class="nav-item searching">
                     <div id="sb-search" class="sb-search">
                        <form><input class="sb-search-input" placeholder="Enter your search term..."
                           type="text" value="" name="search" id="search"><input
                           class="sb-search-submit" type="submit" value=""><span
                           class="sb-icon-search"><i class="fas fa-search"></i></span>
                           <span class="sb-icon-search1"><i class="fas fa-search"></i></span>
                        </form>
                     </div>
                     <div class="megamenu megamenu3"
                        style="background-image:url(assets/img/megamenusbanner.png);background-size: cover; background:#fff; background-position: top center;border-radius: 10px;overflow: visible; position: absolute; right: 0px;">
                        <div class="submenu submenu3">
                           <div class="menuleft menuleft3">
                              <h3> Remote Team</h3>
                              <ul class="ulinesdmen">
                                 <li><i class="fas fa-search"></i> Services1</li>
                                 <li><i class="fas fa-search"></i> Services2</li>
                                 <li><i class="fas fa-search"></i> Services3</li>
                                 <li><i class="fas fa-search"></i> Services4</li>
                                 <li><i class="fas fa-search"></i> Services5</li>
                                 <li><i class="fas fa-search"></i> Services6</li>
                                 <li><i class="fas fa-search"></i> Services7</li>
                              </ul>
                           </div>
                           <div class="menuright menuright3">
                              <h2>Popular Products</h2>
                              <ul>
                                 <li>
                                    <a href="#1"><img class=" lazyloaded"
                                       src="assets/img/ser1.jpeg" alt="Technology"
                                       width="44"><span><strong>PACIFICA</strong> Mattify &
                                    Protect Daily Priming Lotion SPF 35</span></a>
                                 </li>
                                 <li>
                                    <a href="#1"><img src="assets/img/ser2.jpeg" alt="4p"
                                       width="44"><span><strong>ESTEE LAUDER</strong>
                                    Double Wear Stay-In-Place Foundation</span></a>
                                 </li>
                                 <li>
                                    <a href="#1"><img src="assets/img/ser3.jpeg" alt="models"
                                       width="44"><span><strong>E.L.F. COSMETICS</strong>
                                    Tone Adjusting Face Primer - Large</span></a>
                                 </li>
                                 <li><a href="#1"><img class=" lazyloaded"
                                    src="assets/img/ser4.jpeg"
                                    data-src="assets/img/agile-menu-icon.svg"
                                    alt=">Agile & Scrum" width="44"><span><strong>THE
                                    ORDINARY</strong> Serum Foundation</span></a>
                                 </li>
                                 <li>
                                    <a href="#1"><img src="assets/img/ser5.jpeg"
                                       alt="Valued Professionals"
                                       width="44"><span><strong>LOVE WELLNESS</strong> Good
                                    Girl Probiotics</span></a>
                                 </li>
                                 <li>
                                    <a href="#1"><img src="assets/img/ser6.jpeg"
                                       alt="Valued Professionals"
                                       width="44"><span><strong>MEGABABE</strong> Thigh
                                    Rescue</span></a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </li>
                  <li class="nav-item">
                     <a data-bs-toggle="modal" href="#twomodallabel" role="button"
                        class="nav-link questions">
                     <i class="fas fa-user">
                     </i>
                     </a>
                  </li>
               </ul>
            </div>
         </div>
      </nav>
   </div>
</header>
    </div>
	    <div class="mensidebar">
        <div id="container">
            <a href="#1" class="float" target="_blank" style="position: fixed;left: 5px; bottom: 5px;z-index: 999;"> </a>
            <div class="circle" style="animation-delay: -4s"></div>
            <div class="circle" style="animation-delay: -3s"></div>
            <div class="circle" style="animation-delay: -2s"></div>
            <div class="circle" style="animation-delay: -1s"></div>
            <div class="circle" style="animation-delay: 0s"></div>
        </div>
        <div class='wrap'>
            <input type='checkbox' id='checking' style='display:none;' />
            <button class='blob'><i class="fab fa-facebook-f"></i></button>
            <button class='blob'><i class="fab fa-twitter"></i></button>
            <button class='blob'><i class="fab fa-linkedin-in"></i></button>
            <button class='blob'><i class="fab fa-instagram"></i></button>
            <button class='blob'><i class="fab fa-pinterest"></i></button>
            <!-- <button class='blob'>&#x270E;</button>
                <button class='blob'>&#x266B;</button>
                <button class='blob'>&#x2706;</button> -->
            <label class='blob' for='checking'> <span><i class="fas fa-share-alt"></i></span>  </label>
        </div>
    </div>