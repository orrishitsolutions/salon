<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Saloon</title>
    <?php 
            include 'include/header-link.php' 
    ?>

</head>

<body>
    <div class="wrapper">
    <?php 
            include 'include/header.php' 
        ?>
    <div class="small-banner">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.php">Home</a></li> 
                <li class="breadcrumb-item active">Terms and Conditions</li>
            </ol>
        </nav>
        <img src="assets/img/fbanner.jpg" alt="" style="height:450px;width:100%;">
    </div>
	
 
    <section class="pt-5pb-5 blogsdfdk blog-detail_dp">
        <div class="container" style="    width: 1160px;">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-12">
                    <div class="blog-inners">

                       

                        <div class="waste">
                            <div class="well1">
                                <div class="light-text">
                                    <span class="title20">Terms</span>
                                    <h2>Terms and Conditions</h2>
                                </div>
                            </div>
                             

                            <p>Salon GROUP starts a promising chapter of alternative waste management in Rhodes by signing a memorandum of cooperation with the Dodecanese Recycling (DANAEKK). A new promising chapter for the protection of the natural environment started in Rhodes with the beginning of cooperation for the alternative management of waste from excavations, constructions and demolitions, between the
                                Dodecanese Recycling and Esperia Group.</p>

                   
                            <p>Salon GROUP starts a promising chapter of alternative waste management in Rhodes by signing a memorandum of cooperation with the Dodecanese Recycling (DANAEKK). A new promising chapter for the protection of the natural environment started in Rhodes with the beginning of cooperation for the alternative management of waste from excavations, constructions and demolitions, between the
                                Dodecanese Recycling and Esperia Group.</p>
								
                            <p>Salon GROUP starts a promising chapter of alternative waste management in Rhodes by signing a memorandum of cooperation with the Dodecanese Recycling (DANAEKK). A new promising chapter for the protection of the natural environment started in Rhodes with the beginning of cooperation for the alternative management of waste from excavations, constructions and demolitions, between the
                                Dodecanese Recycling and Esperia Group.</p>
                            <p>Salon GROUP starts a promising chapter of alternative waste management in Rhodes by signing a memorandum of cooperation with the Dodecanese Recycling (DANAEKK). A new promising chapter for the protection of the natural environment started in Rhodes with the beginning of cooperation for the alternative management of waste from excavations, constructions and demolitions, between the
                                Dodecanese Recycling and Esperia Group.</p>
								
                            <p>Salon GROUP starts a promising chapter of alternative waste management in Rhodes by signing a memorandum of cooperation with the Dodecanese Recycling (DANAEKK). A new promising chapter for the protection of the natural environment started in Rhodes with the beginning of cooperation for the alternative management of waste from excavations, constructions and demolitions, between the
                                Dodecanese Recycling and Esperia Group.</p>
								
                            <p>Salon GROUP starts a promising chapter of alternative waste management in Rhodes by signing a memorandum of cooperation with the Dodecanese Recycling (DANAEKK). A new promising chapter for the protection of the natural environment started in Rhodes with the beginning of cooperation for the alternative management of waste from excavations, constructions and demolitions, between the
                                Dodecanese Recycling and Esperia Group.</p>
								
                            <p>Salon GROUP starts a promising chapter of alternative waste management in Rhodes by signing a memorandum of cooperation with the Dodecanese Recycling (DANAEKK). A new promising chapter for the protection of the natural environment started in Rhodes with the beginning of cooperation for the alternative management of waste from excavations, constructions and demolitions, between the
                                Dodecanese Recycling and Esperia Group.</p>

                            <div>


                                




                            </div>

                        </div>

                    </div>
                </div>
                

            </div>

        </div>
    </section>
   
    <?php 
            include 'include/footer.php' 
?>