 <section class="foot-top">
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="contact-form text-start" style="    top: 0px;">
                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item" role="presentation"><a class="nav-link needy-tab-link text-dark text-center active-needynav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">GiveOneTime</a></li>
                                <li class="nav-item" role="presentation"><a class="nav-link needy-tab-link text-dark text-center" id="profile-tab home-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Give Monthly</a></li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                    <div class="tebselnis">
                                        <h4>Request A Free Quote</h4>
                                        <p class="pr-uv"> Get a free quote from our specialists on your project. </p>
                                        <div id="formmessage" style="display: none;">Success/Error Message Goes Here</div>
                                        <div>
                                            <div>
                                                <div class="card shadow-inset border-light card-form">
                                                    <div class="card-body p-5">
                                                        <form>
                                                            <input type="text" value="Name" /><input type="text" value="Phone No" /><input type="text" value="Email id" />
                                                            <textarea>Massege</textarea>
                                                            <h6 class="sliders1">Which services are you interested in?</h6>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services1</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services2</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services3</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services4</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services5</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services6</span></div>
                                                            <button type="submit" class="btn sub">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                    <div>
                                        <h4>Request A Free Quote</h4>
                                        <p class="pr-uv"> Get a free quote from our specialists on your project. </p>
                                        <div id="formmessage" style="display: none;">Success/Error Message Goes Here</div>
                                        <div>
                                            <div>
                                                <div class="card shadow-inset border-light card-form">
                                                    <div class="card-body p-5">
                                                        <form>
                                                            <input type="text" value=" Name" /><input type="text" value="Phone No" /><input type="text" value="Email id" />
                                                            <textarea>Massege</textarea>
                                                            <h6 class="sliders1">Which services are you interested in?</h6>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services1</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services2</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services3</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services4</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services5</span></div>
                                                            <div class="box45-dp"><input type="checkbox" /><span> Services6</span></div>
                                                            <button type="submit" class="btn sub">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="clock-digital form-uv-link">
                            <div class="">
                                <div class="appi-portfolio-sec-left" style="background-color: rgb(51 186 244);    top: 0; ">
                                    <div class="owl-carousel00000 owl-carousel owl-theme">
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <div class="cover">
                                                        <div class="container">
                                                            <div class="header-content">
                                                                <h2>Mr. Rakesh Singh</h2>
                                                                <h4>Technologies Pvt. Ltd. delivers high-end fascinating IT solutions to businesses. ‘Class’ and ‘Authenticity’ is what we believe in, and we work.</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-5"><img src="assets/img/testi1.png" alt="images not found"></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <div class="cover">
                                                        <div class="container">
                                                            <div class="header-content">
                                                                <h2>Mr. Rakesh Singh</h2>
                                                                <h4>Technologies Pvt. Ltd. delivers high-end fascinating IT solutions to businesses. ‘Class’ and ‘Authenticity’ is what we believe in, and we work.</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-5"><img src="assets/img/testi2.png" alt="images not found"></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <div class="cover">
                                                        <div class="container">
                                                            <div class="header-content">
                                                                <h2>Mr. Rakesh Singh</h2>
                                                                <h4>Technologies Pvt. Ltd. delivers high-end fascinating IT solutions to businesses. ‘Class’ and ‘Authenticity’ is what we believe in, and we work.</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-5"><img src="assets/img/testi3.png" alt="images not found"></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <div class="cover">
                                                        <div class="container">
                                                            <div class="header-content">
                                                                <h2>Mr. Rakesh Singh</h2>
                                                                <h4>Technologies Pvt. Ltd. delivers high-end fascinating IT solutions to businesses. ‘Class’ and ‘Authenticity’ is what we believe in, and we work.</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-5"><img src="assets/img/testi3.png" alt="images not found"></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <div class="cover">
                                                        <div class="container">
                                                            <div class="header-content">
                                                                <h2>Mr. Rakesh Singh</h2>
                                                                <h4>Technologies Pvt. Ltd. delivers high-end fascinating IT solutions to businesses. ‘Class’ and ‘Authenticity’ is what we believe in, and we work.</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-5"><img src="assets/img/testi3.png" alt="images not found"></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <div class="cover">
                                                        <div class="container">
                                                            <div class="header-content">
                                                                <h2>Mr. Rakesh Singh</h2>
                                                                <h4>Technologies Pvt. Ltd. delivers high-end fascinating IT solutions to businesses. ‘Class’ and ‘Authenticity’ is what we believe in, and we work.</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-5"><img src="assets/img/testi3.png" alt="images not found"></div>
                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="row">
                                                <div class="col-md-7">
                                                    <div class="cover">
                                                        <div class="container">
                                                            <div class="header-content">
                                                                <h2>Mr. Rakesh Singh</h2>
                                                                <h4>Technologies Pvt. Ltd. delivers high-end fascinating IT solutions to businesses. ‘Class’ and ‘Authenticity’ is what we believe in, and we work.</h4>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-5"><img src="assets/img/testi3.png" alt="images not found"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clock-circle">
                                        <svg version="1.1" id="transring" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 414 414" style="enable-background:new 0 0 414 414;" xml:space="preserve">
                                     <path id="Transparent_Ring" class="transrg"style="opacity:0.4;fill:none;stroke:#FFFFFF;stroke-width:2;stroke-miterlimit:10;enable-background:new"d="M84.2,85c31.3-31.5,74.7-51,122.7-51c95.5,0,173,77.5,173,173s-77.5,173-173,173c-47.8,0-91-19.4-122.3-50.7"></path>
                                  </svg>
                                        <button class="trans-dot dot1 active"></button><button class="trans-dot dot2"></button><button class="trans-dot dot3"></button><button class="trans-dot dot4"></button><button class="trans-dot dot5"></button>
                                        <button class="trans-dot dot6"></button><button class="trans-dot dot7"></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
			 <div class="object-text">
        <h2 class="text-uppercase">let’s<br> discuss</h2>
    </div>
    </section>

     