<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Saloon</title>
    <?php 
            include 'include/header-link.php' 
    ?>

</head>

<body>
    <div class="wrapper">
    <?php 
            include 'include/header.php' 
    ?>
    <section class="about-us">
	    <div class="container mx-5">
               <div class="banner-content">
                  <h2 class="text-light text-capitalize">
                     <span class=" display-3 fw-bold ">
                        100+
                     </span>
                     website built <br> that get result
                  </h2>
                  <p class="text-light pb-3">
                     Lorem ipsum dolor sit amet consectetur, adipisicing elit. Laboriosam suscipit <br> porro a mollitia
                     ipsa maxime iure amet consequuntur.
                  </p>
                  <div>
                     <button class="btn border-rounded text-light outline-none" style="background-color:#33baf4;">
                        Get Started Now
                     </button>
                  </div>
               </div>
            </div>
 <img src="./assets/img/abanner.jpg" alt="">
   </section>
   
    <!--<section class="help-me-choose p-t60">

            <div class="container">

                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div class="well1">
                            <div class="light-text">
                                <span class="title20"> Services</span>
                                <h2>Our Services</h2>
                            </div>
                            <div class="light-text1">
                                <p> SALON SERVICES is the best place for elit, sed do eiusmod tempor dolor sit amet, conse ctetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et lorna aliquatd minimam, quis nostrud exercitationoris nisi ut
                                    aliquip ex ea.SALON SERVICES is the best place for elit, sed do eiusmod tempor dolor sit amet, conse ctetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et lorna aliquatd minimam, quis nostrud exercitationoris nisi ut
                                    aliquip ex ea.</p>
                            </div>
                        
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                        <div class="img-ctnt">
                            <img src="./assets/img/image4.jpg" alt="">
                        </div>
                    </div>
                </div>

            </div>

        </section>-->
		    <section class="ultra-reliable my-5 serviceslk">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="base-header2">
                        <h3 class="    padding-bottom: 15px;"> <small>Services</small> What We Do </h3>
                        <p class="solution_dps"> Get specialized protection where you need it most  
						Get specialized protection where you need it most 
						Get specialized protection where you need it most  Get specialized protection where you need it most </p>
                    </div>
                </div>


                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                 <a href="men-services.php">    <div class="img-p  position-relative pb-0">
                        <img src="./assets/img/mensalons.jpg" alt="">

                        <div class="shadow-b position-absolute bg-white">
                            <div class="img-overlay-box text-center rounded-circle ">
                                <div class="d-inline-block mt-30">
                                    <b class="fs-6 f-700">
                    &nbsp;&nbsp;Men&nbsp;&nbsp;
                  </b>
                                    <span class="fs-6 f-500 light-text20 ">
                    Services
                  </span>
                                </div>
                            </div>
                        </div>
 

                    </a>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                   <a href="women-services.php"> <div class="img-p position-relative pb-0">
                        <img src="./assets/img/womenss.jpg" alt="">

                        <div class="shadow-b position-absolute bg-white">
                            <div class="img-overlay-box text-center rounded-circle ">
                                <div class="d-inline-block mt-30">
                                    <b class="fs-6 f-700">
                    &nbsp;&nbsp;Women&nbsp;&nbsp;
                  </b>
                                    <span class="fs-6 f-500 light-text20 ">
                    Services
                  </span>
                                </div>
                            </div>
                        </div>
                      
                    
                    </div></a>
                </div> 
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                 <a href="#men-services.php">    <div class="img-p  position-relative pb-0">
                        <img src="./assets/img/trandmakeover.jpg" alt="">

                        <div class="shadow-b position-absolute bg-white">
                            <div class="img-overlay-box text-center rounded-circle ">
                                <div class="d-inline-block mt-30">
                                    <b class="fs-6 f-700">
                  &nbsp;&nbsp;Trend&nbsp;&nbsp; 
                  </b>
                                    <span class="fs-6 f-500 light-text20 ">
                    Makeovers
                  </span>
                                </div>
                            </div>
                        </div>
 

                    </a>
                    </div>
                </div>

                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                   <a href="#women-services.php"> <div class="img-p position-relative pb-0">
                        <img src="./assets/img/causeshare.jpg" alt="">

                        <div class="shadow-b position-absolute bg-white">
                            <div class="img-overlay-box text-center rounded-circle ">
                                <div class="d-inline-block mt-30">
                                    <b class="fs-6 f-700">
                    &nbsp;&nbsp;&nbsp;&nbsp;Causes&nbsp;&nbsp;&nbsp;&nbsp; 
                  </b>
                                    <span class="fs-6 f-500 light-text20 ">
                     Hair
                  </span>
                                </div>
                            </div>
                        </div>
                      
                    
                    </div></a>
                </div>
            </div>
        </div>
    </section>
	  <section class="bannersectionsd">
		 <div class="container">
		 <div class="row">
		 <div class="col-md-12">
		 <div class="revealOnScroll rotateIn animated" data-animation="rotateIn">
            <h3 class="heading4 yellowfont">Let us offer you - The Best Salon Services</h3>
            <div class="sub-txt3 normal mauto text-center mb10 whitefont">Haircut - Styling - Colouring - Extensions - Treatments -Bridal Makeup</div>
            <div class="sub-txt3 normal mauto text-center mb10 whitefont"><em>we can do it all  !!!</em></div>
            <div class="text-center mt20"><a href="make-appointment.php" class="sgbtn19">Make An Appointment</a> </div>
        </div>
		 </div>
		 </div>
		 </div>
         </section>
	 
	     

 




        <!-- package section started from here -->


        <section class="package-slider package-slider1 serivicelsd homepackages" style="margin-top:0px;">
            <div class="container">
               <div class="base-header2">
                  <h3> <small>Packages </small> Our Packages </h3>
                  <p>Step in to look great! We have the best services and offers waiting for you! Step in to look great! We have the best services and offers waiting for you! Step in to look great! We have the best services and offers waiting for you!</p>
               </div>
               <div class="row">
                  <div class="owl-carousel owl-theme pkg-owl-carousel">
                     <div class="item">
                        <!-- card-1-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/wax.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Bleach
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-1-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-2-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/body.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Body Care
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-2-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-3-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/waximg.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              De-Tan Pack
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-3-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-4-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/make.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Deal of The Day
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-4-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-5-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/face.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Face Care
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-5-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-6-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/hair.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Hair Care
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-6-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-7-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/bodys.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Manicure & Pedicure
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-7-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-8-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/makeup.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Party Makeup
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-8-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-9-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/custom.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Threading
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-9-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-10-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/wax.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Waxing
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-10-end-here -->
                     </div>
                     <div class="item">
                        <!-- card-11-here -->
                        <div class="card-parent">
                           <span>
                           <img class="child-img" src="./assets/img/prebody.png" alt="">
                           </span>
                           <div class="ctnt">
                              <span>
                              Pre Bridal
                              </span>
                           </div>
                           <div class="line-p">
                              <span class="line-cp">
                              </span>
                           </div>
                           <div class="p-t">
                              <p>
                                 Essential antivirus protection for Windows PCs
                              </p>
                           </div>
                           <div class="sale-off">
                              <span>
                              20% OFF
                              </span>
                           </div>
                           <div class="price">
                              <p>
                                 From
                                 <br>
                                 <span class="bold">
                                 ₹ 479.20
                                 </span>
                              </p>
                           </div>
                           <div class="learn-more">
                              <a href="package-detail.php" class="btn-lrn-m"> Learn More</a>
                           </div>
                        </div>
                        <!-- card-11-end-here -->
                     </div>
                  </div>
               </div>
            </div>
         </section>

        <!-- package section ended here -->


        <!-- help me choose section starts from here-->
 
      <?php 
            include 'testimonils-section.php' 
    ?>

    
     

    <?php 
            include 'include/footer.php' 
        ?>