<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
   <p class="text-muted mb-1 mb-md-0">Copyright © 2021 <a href="http://niswarthsewa.com/" target="_blank">NGO Nishivarth</a>.</p>
</footer>
</div>
</div>
<script src="<?=base_url()?>assets-orrish/js/admin-js/jquery-3.3.1.min.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/core/core.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/chartjs/Chart.min.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/jquery.flot/jquery.flot.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/jquery.flot/jquery.flot.resize.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/apexcharts/apexcharts.min.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/feather-icons/feather.min.js"></script>
<script src="<?=base_url()?>assets-orrish/js/admin-js/jquery-confirm.js"></script>
<script src="<?=base_url()?>assets-orrish/js/template.js"></script>
<script src="<?=base_url()?>assets-orrish/js/dashboard-dark.js"></script>
<script src="<?=base_url()?>assets-orrish/js/datepicker.js"></script>



 <script src="<?=base_url()?>assets-orrish/vendors/datatables.net/jquery.dataTables.js"></script>   
<script src="<?=base_url()?>assets-orrish/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>

  
<script src="<?=base_url()?>assets-orrish/js/data-table.js"></script>   
<!-- Plugin js for this page -->


<script src="<?=base_url()?>assets-orrish/vendors/ace-builds/src-min/ace.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/ace-builds/src-min/theme-chaos.js"></script>
<!-- End plugin js for this page -->	
<!-- Custom js for this page -->
<script src="<?=base_url()?>assets-orrish/js/tinymce.js"></script>
<script src="<?=base_url()?>assets-orrish/js/simplemde.js"></script>
<script src="<?=base_url()?>assets-orrish/js/ace.js"></script>
<script src="<?=base_url()?>assets-orrish/vendors/simplemde/simplemde.min.js"></script>
<!-- <script src="<?=base_url()?>assets-orrish/vendors/tinymce/tinymce.min.js" referrerpolicy="origin"></script> -->


<script src="https://cdn.tiny.cloud/1/a99g5fwjkqb1x84tybwqefbit62mnkoc9w97hvfwz1fxlary/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>

<script src="<?=base_url()?>assets-orrish/ckeditor/ckeditor.js"></script>
<script src="<?=base_url()?>assets-orrish/js/admin-js/custome.js"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


</body>
</html>

